window.addEventListener('load', () => {
  const laugh = document.getElementById("joker-laugh");
  laugh.volume = 0.6;

  const music = document.getElementById("bg-music");
  music.volume = 0.3;

  document.body.addEventListener("click", () => {
    music.play();
    laugh.play();
  });
});
